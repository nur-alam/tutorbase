<?php
/**
 * Constant variables.
 *
 * @package Tutorowl
 */

define( 'TUTOROWL_PATH', __DIR__ );
define( 'TUTOROWL_ASSETS_PATH', __DIR__ . '/assets' );
define( 'TUTOROWL_VERSION', '1.0.0' );
