<?php
/**
 * The main template file
 *
 * @package Tutorowl
 */

wp_footer();

?>

</body>

</html>